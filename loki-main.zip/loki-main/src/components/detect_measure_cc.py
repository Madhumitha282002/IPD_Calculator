import cv2
import numpy as np
import tensorflow as tf
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as viz_utils

# Load the fine-tuned model
model_dir = 'path/to/fine_tuned_model_directory'
detect_fn = tf.saved_model.load(model_dir)

# Load the label map
label_map_path = 'path/to/label_map.pbtxt'
label_map = label_map_util.load_labelmap(label_map_path)
categories = label_map_util.convert_label_map_to_categories(label_map, max_num_classes=1)
category_index = label_map_util.create_category_index(categories)

# Load and preprocess the image
image_path = 'path/to/test_image.jpg'
image = cv2.imread(image_path)
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
image_np = np.expand_dims(image_rgb, axis=0)

# Perform object detection
output_dict = detect_fn(image_np)

# Get the coordinates of the detected bounding box
bbox = output_dict['detection_boxes'][0]
y_min, x_min, y_max, x_max = bbox

# Calculate the length of the credit card in pixels
credit_card_length_pixels = (y_max - y_min) * image.shape[0]

print("Length of the credit card in pixels:", credit_card_length_pixels)

# Visualize the detection
viz_utils.visualize_boxes_and_labels_on_image_array(
    image_np[0],
    output_dict['detection_boxes'][0],
    output_dict['detection_classes'][0].astype(np.int32),
    output_dict['detection_scores'][0],
    category_index,
    use_normalized_coordinates=True,
    max_boxes_to_draw=200,
    min_score_thresh=0.30,
    agnostic_mode=False
)

# Display the image with the detection
cv2.imshow('Detected Credit Card', image_np[0])
cv2.waitKey(0)
cv2.destroyAllWindows()